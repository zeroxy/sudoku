#include <stdlib.h>
#include <stdio.h>
#include <set>
  
#include "grader.h"
#include "lang.h"
 
#define N 100
  
using namespace std;
  
set<int> bigram[56];
  
  
void excerpt(int *E){
    int ans=0, ans_score=0;
  
    for(int i=0;i<56;i++){
        int score = 0;
 
        for(int j=0;j<N-1;j++) if(bigram[i].find( (E[j]<<16) | E[j+1]) != bigram[i].end()) score++; 
         
        if(score > ans_score){
            ans_score = score;
            ans = i;
        }
    }
  
    ans = language(ans);
  
    for(int j=0;j<N-1;j++) if(bigram[ans].find( (E[j]<<16) | E[j+1]) == bigram[ans].end()) bigram[ans].insert( (E[j]<<16) | E[j+1]);
}
