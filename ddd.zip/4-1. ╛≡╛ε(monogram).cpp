#include <stdlib.h>
#include <stdio.h>
#include <set>
  
#include "grader.h"
#include "lang.h"
  
#define N 100
  
using namespace std;
  
int mono[56][2<<16];
  
  
void excerpt(int *E){
    int ans=0, ans_score=0;
  
    for(int i=0;i<56;i++){
        int score = 0;
 
        for(int j=0;j<N;j++) if(mono[i][E[j]]) score++;
           
        if(score > ans_score){
            ans_score = score;
            ans = i;
        }
    }
  
    ans = language(ans);
  
    for(int j=0;j<N;j++) mono[ans][E[j]] = 1;
}
