#include <stdio.h>

int main(){
	int T;
	char* RESULT[2] = {"NO\0", "YES\0"};
	scanf("%d", &T);
	
	for (int t =1; t<=T; t++){
		int result = 0;
		int N;
		int data[100000]={0,};
		int data1[100000]={0,};
		scanf("%d", &N);
		for (int n = 0 ; n<N; n++){
			int h, l;
			scanf("%d %d", &h, &l);
			data[l]++;
			data1[h]++;
		}
		for (int i =0 ;i < 100000; i++){
			//if(data[i]==0){
			//	continue;
			//} else 
			if( data[i] >= ((N*2)/10) ){
				result = 1;
				break;
			}
			
		}
		printf("#%d %s\n", t, *(RESULT+result));
	}
	return 0;
}
