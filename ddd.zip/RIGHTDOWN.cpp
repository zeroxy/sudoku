#include <stdio.h>
int map[1001][1001];
int data[1001][1001]={{0,},};
int main(){
	int H, W, N;
	
	scanf("%d %d %d", &H, &W, &N);
	data[0][0] = N-1;
	for (int h=0; h< H; h++){
		for(int w =0; w<W; w++){
			scanf("%d", &map[h][w]);
		}
	}
	for(int w = 0; w< W; w++){
		for(int h = 0; h < H; h++){	
			data[h][w+1] += data[h][w]/2 + map[h][w]*(data[h][w]%2);
			data[h+1][w] += data[h][w]/2 + (1-map[h][w])*(data[h][w]%2);
			map[h][w] = (map[h][w]+(data[h][w]%2)) %2;
		}
	}
	int x = 0;
	int y = 0;
	while(x<W && y<H){
		if (map[y][x] == 1)
			x++;
		else 
			y++;

	}
	printf("%d %d",y+1,x+1);
	return 0;
}

/*


3 4 3
1 0 1 1
0 1 0 0
1 0 1 0


*/
