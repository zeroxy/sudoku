#include <stdio.h>

int main (){
	int data[1000][1000];
	
	return 0;
}
